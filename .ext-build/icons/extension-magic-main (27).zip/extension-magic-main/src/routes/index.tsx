import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Suspense } from "react";
import { SiteHeader } from "@/components/site/Header";
import { Card } from "@/components/ui/card";
import {
  ChevronRight,
  Sparkles,
  Cpu,
  Mic,
  Infinity as InfinityIcon,
  Shield,
  Wand2,
  BrainCircuit,
  MousePointerClick,
  UploadCloud,
  Zap,
  Eraser,
  MessageSquare,
  Bot,
  Puzzle,
  StickyNote,
  Boxes,
  Check,
  Download,
  CheckCircle2,
} from "lucide-react";
import { getPublicPlans } from "@/lib/license.functions";
import { formatPrice } from "@/lib/license-utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rise Lovable — Domine o Lovable em outro nível" },
      {
        name: "description",
        content:
          "A extensão definitiva para power-users do Lovable.dev. Sidebar IA, prompt por voz, uso ilimitado e licenças validadas em tempo real.",
      },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-[#050505] text-white">
      <SiteHeader />
      <main>
        <Hero />
        <HowItWorks />
        <Features />
        <Suspense fallback={<div className="py-24 text-center text-white/50">Carregando planos…</div>}>
          <Plans />
        </Suspense>
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* 1. HERO                                                             */
/* ------------------------------------------------------------------ */

function Hero() {
  return (
    <section className="rise-bg overflow-hidden border-b border-white/5">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 md:py-28 lg:grid-cols-2 lg:gap-16">
        <div>
          <div className="chip-neon mb-8 inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest">
            <Sparkles className="h-3 w-3" />
            Ferramenta secreta dos usuários avançados de IA
          </div>

          <h1 className="font-display text-5xl font-extrabold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
            USE O LOVABLE
            <br />
            EM <span className="text-gradient-red">OUTRO NÍVEL.</span>
          </h1>

          <p className="mt-6 max-w-lg text-lg leading-relaxed text-white/60">
            A extensão definitiva para{" "}
            <span className="font-medium text-white">produtividade com IA</span>
            , automação e uso avançado do Lovable.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Link
              to="/planos"
              className="btn-neon group inline-flex h-12 items-center gap-2 rounded-full px-7 text-sm font-bold uppercase tracking-wider text-white"
            >
              Obter acesso
              <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/auth"
              className="inline-flex h-12 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-6 text-sm font-semibold text-white backdrop-blur-sm transition hover:border-white/20 hover:bg-white/10"
            >
              <Sparkles className="h-4 w-4 text-primary" />
              Testar grátis
            </Link>
          </div>

          <div className="mt-10 grid max-w-lg grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { icon: Cpu, label: "Sidebar IA" },
              { icon: Mic, label: "Prompt por Voz" },
              { icon: InfinityIcon, label: "Uso Infinito" },
              { icon: Shield, label: "Licença PRO" },
            ].map((f) => (
              <div
                key={f.label}
                className="chip-neon inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-[11px] font-semibold"
              >
                <f.icon className="h-3.5 w-3.5" />
                {f.label}
              </div>
            ))}
          </div>
        </div>

        {/* Mockup */}
        <div className="relative mx-auto w-full max-w-md">
          <div className="pointer-events-none absolute -inset-10 -z-0 rounded-[40px] bg-primary/25 blur-[90px]" />
          <div className="ring-glow relative overflow-hidden rounded-3xl border border-white/10 bg-[#0a0a0a]">
            <div className="flex items-center justify-between border-b border-white/5 bg-white/[0.02] px-4 py-3">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full border border-primary/50 bg-primary/20" />
                <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
                <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
              </div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-white/40">
                Rise Lovable · Extension
              </span>
              <div className="h-3 w-3" />
            </div>

            <div className="space-y-4 p-5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-white/50">&gt; RISE LOVABLE 7.0</span>
                <span className="rounded bg-primary/15 px-2 py-0.5 font-mono text-[10px] font-bold text-primary">
                  AUTH
                </span>
              </div>

              {[
                { label: "Sessão", value: "PH Teste 2" },
                { label: "Status", value: "Sincronizado" },
                { label: "Workspace", value: "Lovable" },
              ].map((row) => (
                <div
                  key={row.label}
                  className="flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.02] px-4 py-3 text-xs"
                >
                  <span className="text-white/50">{row.label}</span>
                  <span className="font-semibold text-white/90">{row.value}</span>
                </div>
              ))}

              <div className="flex gap-1 rounded-xl border border-white/5 bg-white/[0.02] p-1 text-[11px]">
                <div className="flex-1 rounded-lg bg-primary/15 py-1.5 text-center font-semibold text-primary">
                  Comando
                </div>
                <div className="flex-1 py-1.5 text-center text-white/50">Ações</div>
                <div className="flex-1 py-1.5 text-center text-white/50">Histórico</div>
              </div>

              <div className="rounded-xl border border-white/5 bg-black/40 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                    Insira seu prompt
                  </span>
                  <span className="chip-neon rounded-full px-2 py-0.5 text-[10px] font-bold">
                    Assistido
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="h-1.5 w-4/5 rounded bg-white/10" />
                  <div className="h-1.5 w-3/5 rounded bg-white/10" />
                  <div className="h-1.5 w-2/3 rounded bg-white/10" />
                </div>
                <button className="btn-neon mt-4 w-full rounded-lg py-2 text-[11px] font-bold uppercase tracking-widest text-white">
                  Enviar
                </button>
              </div>
            </div>
          </div>

          <div className="absolute -bottom-4 -left-4 flex items-center gap-3 rounded-2xl border border-white/10 bg-black/70 p-3 pr-4 backdrop-blur-xl">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary/60 shadow-[0_0_20px_oklch(0.63_0.245_25/0.6)]">
              <CheckCircle2 className="h-5 w-5 text-white" />
            </div>
            <div className="text-[11px] leading-tight">
              <div className="font-bold">Licença ativa</div>
              <div className="text-white/50">Validada em tempo real</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* 2. COMO FUNCIONA                                                    */
/* ------------------------------------------------------------------ */

function HowItWorks() {
  const steps = [
    {
      n: "01",
      title: "Baixe o instalador",
      desc: "Um clique no botão, download imediato. Sem cadastro, sem espera, sem loja de extensões.",
    },
    {
      n: "02",
      title: "Instale no navegador",
      desc: "Ative o modo desenvolvedor, arraste o ZIP e pronto. Funciona em Chrome, Edge, Brave, Opera, Arc.",
    },
    {
      n: "03",
      title: "Pronto pra usar",
      desc: "Abra o Lovable, ative a extensão com sua Key e envie quantos comandos quiser. Sem gastar créditos.",
    },
  ];

  return (
    <section className="bg-panel-alt border-b border-white/5 py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16 text-center">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.35em] text-primary">
            Como funciona
          </div>
          <h2 className="font-display text-4xl font-extrabold tracking-tight md:text-5xl">
            Instale, ative e domine em
            <br />
            menos de <span className="text-gradient-red">60 segundos.</span>
          </h2>
        </div>

        <div className="relative grid gap-6 md:grid-cols-3">
          {/* linha conectora */}
          <div className="pointer-events-none absolute left-[10%] right-[10%] top-[62px] hidden h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent md:block" />

          {steps.map((s) => (
            <div
              key={s.n}
              className="relative rounded-2xl border border-white/5 bg-white/[0.02] p-8 text-center backdrop-blur-sm transition hover:border-primary/30"
            >
              <div className="ring-glow mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-2xl border border-primary/40 bg-black">
                <span className="font-display text-3xl font-black text-gradient-red">
                  {s.n}
                </span>
              </div>
              <h3 className="font-display text-xl font-bold">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-white/60">{s.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.35em] text-white/40">
            Comece agora mesmo
          </div>
          <Link
            to="/planos"
            className="btn-neon inline-flex h-14 items-center gap-3 rounded-2xl px-8 text-sm font-bold uppercase tracking-wider text-white"
          >
            <Download className="h-5 w-5" />
            Baixar extensão grátis
          </Link>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] text-white/50">
            <span className="flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-primary" /> Grátis para baixar
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-primary" /> Última versão v20.5.2
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="h-3.5 w-3.5 text-primary" /> Chrome · Edge · Brave · Opera · Arc
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* 3. RECURSOS CORE (bento grid 12)                                    */
/* ------------------------------------------------------------------ */

function Features() {
  const items = [
    {
      icon: Wand2,
      title: "Reescrever",
      desc: "Refine seus prompts com IA antes de enviar. Transforme ideias soltas em comandos cirúrgicos que geram resultados perfeitos na primeira tentativa.",
    },
    {
      icon: BrainCircuit,
      title: "Modo Pensar",
      desc: "Ative o raciocínio profundo da IA com um clique. Ideal para arquiteturas complexas, debugging avançado e decisões técnicas críticas.",
    },
    {
      icon: MousePointerClick,
      title: "Seletor de Elementos",
      desc: "Clique em qualquer elemento da tela e edite-o instantaneamente. Sem digitar caminhos, sem perder tempo descrevendo o que você quer alterar.",
    },
    {
      icon: Mic,
      title: "Comando de Voz",
      desc: "Fale seus prompts naturalmente. A transcrição em tempo real captura suas ideias enquanto você pensa, acelerando seu fluxo criativo.",
    },
    {
      icon: UploadCloud,
      title: "Upload de Arquivos & Imagens",
      desc: "Envie imagens, PDFs e referências de design direto no chat. A IA usa esses arquivos para construir interfaces fiéis ao seu desejo.",
    },
    {
      icon: Zap,
      title: "Funções Especiais",
      desc: "Atalhos, automações e ações rápidas integradas ao Lovable. Acelere tarefas repetitivas e mantenha o foco no que importa: criar.",
    },
    {
      icon: Eraser,
      title: "Remoção de Marca D'água",
      desc: "Entregue projetos 100% limpos para seus clientes. Sem branding externo, sem identificação de terceiros — apenas a sua marca.",
    },
    {
      icon: MessageSquare,
      title: "Chat Ao Vivo (Anti-Créditos)",
      desc: "Envie comandos diretamente pelo chat oficial do Lovable. Nossa tecnologia intercepta as mensagens e processa tudo sem tocar nos créditos.",
    },
    {
      icon: Bot,
      title: "Assistente Alexa",
      desc: "IA dedicada que responde dúvidas, sugere prompts e guia seu projeto do zero ao deploy. Como ter um sênior ao seu lado 24/7.",
    },
    {
      icon: Puzzle,
      title: "Sistema de Skills",
      desc: "Ative skills especialistas (SEO, Performance, UI/UX, Copy) ou crie as suas próprias. Transforme a IA num especialista em segundos.",
    },
    {
      icon: StickyNote,
      title: "Notas Flutuantes",
      desc: "Anotações rápidas fixadas na tela que permanecem mesmo após fechar o navegador. Ideal para guardar prompts, ideias e referências.",
    },
    {
      icon: Boxes,
      title: "Seleção de Agente",
      desc: "Escolha qual IA processa seus comandos: Claude Opus 4.8, Gemini PRO 3.2 ou GPT 5.5. Use o modelo certo para cada tipo de tarefa.",
    },
  ];

  return (
    <section className="bg-deep border-b border-white/5 py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-14 grid gap-6 md:grid-cols-2 md:items-end">
          <div>
            <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.35em] text-primary">
              Recursos Core
            </div>
            <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl">
              Tecnologia de elite para
              <br />
              performance absoluta.
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-white/50 md:text-right">
            Desenvolvemos a Rise Lovable para ser o núcleo operacional
            <br className="hidden md:block" />
            do seu fluxo no Lovable. Sem ruído, apenas resultados.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((it, i) => {
            const num = String(i + 1).padStart(2, "0");
            return (
              <Card
                key={it.title}
                className="group relative overflow-hidden border-white/5 bg-white/[0.015] p-6 transition-all hover:border-primary/40 hover:bg-white/[0.04]"
              >
                <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-primary/15 opacity-0 blur-3xl transition-opacity group-hover:opacity-100" />
                <div className="mb-6 flex items-start justify-between">
                  <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary shadow-[0_0_20px_oklch(0.63_0.245_25/0.2)]">
                    <it.icon className="h-4.5 w-4.5" />
                  </div>
                  <span className="font-display text-2xl font-black text-white/10">
                    {num}
                  </span>
                </div>
                <h3 className="font-display text-lg font-bold">{it.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/55">{it.desc}</p>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* 4. PLANOS                                                           */
/* ------------------------------------------------------------------ */

function Plans() {
  const getPlans = useServerFn(getPublicPlans);
  const { data: plans } = useSuspenseQuery({
    queryKey: ["plans", "public"],
    queryFn: () => getPlans(),
  });

  const highlightSlug = "monthly";

  return (
    <section className="bg-panel border-b border-white/5 py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16 text-center">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.35em] text-primary">
            Planos
          </div>
          <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl">
            Escolha o plano que combina
            <br />
            com <span className="text-gradient-red">seu ritmo.</span>
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {plans.slice(0, 6).map((plan) => {
            const highlight = plan.slug === highlightSlug;
            const features = (plan.features as string[]) ?? [];
            return (
              <Card
                key={plan.id}
                className={`relative flex flex-col overflow-hidden p-8 transition-all ${
                  highlight
                    ? "ring-glow border-primary/50 bg-gradient-to-b from-[#180606] to-black"
                    : "border-white/5 bg-white/[0.02] hover:border-primary/30"
                }`}
              >
                {highlight && (
                  <div className="absolute -top-px left-1/2 -translate-x-1/2 rounded-b-full bg-gradient-to-r from-primary to-primary/60 px-4 py-1 text-[10px] font-bold uppercase tracking-widest text-white shadow-[0_0_20px_oklch(0.63_0.245_25/0.6)]">
                    Mais popular
                  </div>
                )}

                <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.3em] text-primary">
                  {plan.duration_days} {plan.duration_days === 1 ? "dia" : "dias"}
                  {" · "}
                  {plan.max_devices} disp.
                </div>
                <h3 className="font-display text-2xl font-extrabold">{plan.name}</h3>

                <div className="my-6 flex items-baseline gap-1">
                  {plan.price_cents === 0 ? (
                    <span className="font-display text-5xl font-black">Grátis</span>
                  ) : (
                    <>
                      <span className="text-sm font-bold text-white/60">R$</span>
                      <span className="font-display text-5xl font-black tracking-tight">
                        {formatPrice(plan.price_cents).replace(/^R\$\s?/, "")}
                      </span>
                    </>
                  )}
                </div>

                {plan.description && (
                  <p className="mb-6 text-sm text-white/55">{plan.description}</p>
                )}

                <ul className="mb-8 flex-1 space-y-2.5 text-sm">
                  <li className="flex items-center gap-2.5">
                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/15 text-primary">
                      <Check className="h-3 w-3" />
                    </div>
                    Acesso ilimitado
                  </li>
                  {features.map((f) => (
                    <li key={f} className="flex items-center gap-2.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/15 text-primary">
                        <Check className="h-3 w-3" />
                      </div>
                      {FEATURE_LABEL[f] ?? f}
                    </li>
                  ))}
                </ul>

                <Link
                  to="/planos"
                  className={`inline-flex h-12 items-center justify-center rounded-xl text-xs font-bold uppercase tracking-widest transition ${
                    highlight
                      ? "btn-neon text-white"
                      : "border border-white/10 bg-white/5 text-white hover:border-primary/40 hover:bg-white/10"
                  }`}
                >
                  {plan.price_cents === 0 ? "Testar grátis" : `Assinar ${plan.name}`}
                </Link>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

const FEATURE_LABEL: Record<string, string> = {
  unlimited: "Recursos ilimitados",
  key_daily: "Chaves diárias",
  key_weekly: "Chaves semanais",
  key_monthly: "Chaves mensais",
};

/* ------------------------------------------------------------------ */
/* 5. CTA FINAL                                                        */
/* ------------------------------------------------------------------ */

function FinalCTA() {
  return (
    <section className="bg-band py-28">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <div className="chip-neon mb-8 inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-widest">
          <span className="h-1.5 w-1.5 rounded-full bg-primary dot-pulse" />
          Última chamada
        </div>

        <h2 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-6xl">
          Pare de queimar créditos.
          <br />
          <span className="text-gradient-red">Comece a dominar.</span>
        </h2>

        <p className="mx-auto mt-6 max-w-xl text-sm leading-relaxed text-white/60 md:text-base">
          15 dias de garantia. Setup em 60 segundos. Sem cartão, sem enrolação.
          Se não gostar, devolvemos cada centavo.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link
            to="/planos"
            className="btn-neon group inline-flex h-14 items-center gap-2 rounded-2xl px-8 text-sm font-bold uppercase tracking-wider text-white"
          >
            Ativar Rise Lovable agora
            <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <Link
            to="/planos"
            className="inline-flex h-14 items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-8 text-sm font-semibold text-white backdrop-blur-sm transition hover:border-white/20 hover:bg-white/10"
          >
            Ver todos os planos
          </Link>
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-[11px] font-bold uppercase tracking-widest text-white/50">
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Garantia 15 dias
          </span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Suporte humano
          </span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Setup em 60s
          </span>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* FOOTER                                                              */
/* ------------------------------------------------------------------ */

function Footer() {
  return (
    <footer className="border-t border-white/5 bg-black py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 text-xs text-white/40 md:flex-row">
        <div className="flex items-center gap-2">
          <span className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br from-primary to-primary/60 text-[10px] font-black text-white">
            R
          </span>
          <span className="font-semibold text-white/70">Rise Lovable</span>
          <span>© {new Date().getFullYear()}</span>
        </div>
        <div className="flex items-center gap-6">
          <Link to="/planos" className="hover:text-white">Planos</Link>
          <Link to="/auth" className="hover:text-white">Entrar</Link>
        </div>
      </div>
    </footer>
  );
}
